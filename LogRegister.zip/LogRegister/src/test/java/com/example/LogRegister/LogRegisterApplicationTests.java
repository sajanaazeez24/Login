package com.example.LogRegister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
