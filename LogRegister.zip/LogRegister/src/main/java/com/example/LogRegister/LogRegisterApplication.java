package com.example.LogRegister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogRegisterApplication.class, args);
	}

}
